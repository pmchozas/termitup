import requests
import json
import check_term
import re
from unicodedata import normalize
import wsidCode
import extrafunctions
import jsonFile
import eurovocCode


